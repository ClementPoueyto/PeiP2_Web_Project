window.onload=function (){
    let start=document.getElementById("start");
    start.onclick = function(){
        document.location.href = "jeu.php";}
}