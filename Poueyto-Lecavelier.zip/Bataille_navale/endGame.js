window.onload = function () {
    let continuer= document.getElementById("continuer");
    continuer.onclick= function(){
        document.location.href = "index.php";
    }
}